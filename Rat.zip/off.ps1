﻿Set-MpPreference -SubmitSamplesConsent NeverSend 
Set-MpPreference -MAPSReporting Disable 
Set-MpPreference -DisableRemovableDriveScanning $false 
Set-NetFirewallProfile -Profile Domain,Public,Private -Enabled False 